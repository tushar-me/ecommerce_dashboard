<script setup>
import AppLayout from "@/components/Layouts/AppLayout.vue";
</script>
<template>
    <AppLayout>
        <section class="px-4">
            <div class="bg-white p-4">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <Icon name="material-symbols:settings-outline-rounded" class="text-3xl text-primary" />
                        <h3 class="text-primary text-3xl font-semibold">Setting</h3>
                    </div>
                </div>
            </div>
        </section>
    </AppLayout>
</template>

<script setup lang="ts">

</script>

<template>
  <RouterLink class="text-5xl" to="/dashboard">dashboard</RouterLink>
</template>

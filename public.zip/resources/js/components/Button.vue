<template>
    <button class="bg-primary text-white py-2 px-8">
        <slot />
    </button>
</template>
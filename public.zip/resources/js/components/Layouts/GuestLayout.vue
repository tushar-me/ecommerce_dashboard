<template>
    <div class="flex items-center justify-center w-full h-screen">
        <slot />
    </div>
</template>